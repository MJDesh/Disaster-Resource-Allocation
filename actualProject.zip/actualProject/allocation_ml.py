import pandas as pd
import numpy as np

# Load processed distance & cluster data
dist_df = pd.read_csv("warehouse_disaster_distances.csv")
clusters = pd.read_csv("disaster_cluster_summary.csv")

# Merge distance info with cluster demand
merged = dist_df.merge(clusters, on='Cluster_ID', how='left')

# Compute weights based on inverse distance
epsilon = 1e-6
merged['Weight'] = 1 / (merged['Distance_km'] + epsilon)

# Normalize weights per cluster
merged['Weight_Sum'] = merged.groupby('Cluster_ID')['Weight'].transform('sum')
merged['Fraction'] = merged['Weight'] / merged['Weight_Sum']

# Allocate demand proportionally, respecting warehouse capacity
merged['Allocated_LMT'] = np.minimum(merged['Fraction'] * merged['Cluster_Demand_LMT'], merged['Warehouse_Capacity_LMT'])

# Save allocation
allocation_cols = ['Warehouse', 'Cluster_ID', 'Distance_km', 'Warehouse_Capacity_LMT', 
                   'Cluster_Demand_LMT', 'Allocated_LMT']
merged[allocation_cols].to_csv("allocation_ml.csv", index=False)

print("Proportional allocation saved as allocation_ml.csv")
