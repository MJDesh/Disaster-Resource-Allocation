import pandas as pd
import numpy as np
from sklearn.cluster import KMeans

# Load processed disasters
dis_df = pd.read_csv("disasters_2025_geo.csv")

# Extract coordinates and weights
X = dis_df[['Latitude', 'Longitude']].to_numpy()
weights = dis_df['Demand_LMT'].to_numpy()

# Choose number of clusters (example: 5)
k = 5

# Weighted KMeans
kmeans = KMeans(n_clusters=k, random_state=42)
dis_df['Cluster_ID'] = kmeans.fit_predict(X, sample_weight=weights)

# Summarize clusters
cluster_summary = dis_df.groupby('Cluster_ID').agg({
    'Latitude': 'mean',
    'Longitude': 'mean',
    'Demand_LMT': 'sum'
}).reset_index()

cluster_summary.columns = ['Cluster_ID', 'Centroid_Latitude', 'Centroid_Longitude', 'Total_Demand_LMT']

cluster_summary.to_csv("disaster_cluster_summary.csv", index=False)
print("Disaster clustering done and summary saved!")
