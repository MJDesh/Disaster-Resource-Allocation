import pandas as pd
import folium

merged = pd.read_csv("predicted_allocation.csv")
fci_df = pd.read_csv("fci_warehouses_geo.csv")
clusters = pd.read_csv("disaster_clusters.csv")

# Base map
m = folium.Map(location=[20, 90], zoom_start=4)

# Plot warehouses
for _, w in fci_df.iterrows():
    folium.CircleMarker(
        location=[w['Latitude'], w['Longitude']],
        radius=6,
        color='green',
        popup=f"{w['State']} - Capacity: {w['Total_Capacity']}"
    ).add_to(m)

# Plot disaster clusters
for _, c in clusters.iterrows():
    folium.CircleMarker(
        location=[c['Latitude'], c['Longitude']],
        radius=6,
        color='red',
        popup=f"Cluster {c['Cluster_ID']} - Demand: {c['Demand_Weight']}"
    ).add_to(m)

# Draw lines for allocations
for _, row in merged.iterrows():
    warehouse = fci_df[fci_df['State']==row['Warehouse']].iloc[0]
    cluster = clusters[clusters['Cluster_ID']==row['Cluster_ID']].iloc[0]
    folium.PolyLine(
        locations=[[warehouse['Latitude'], warehouse['Longitude']],
                   [cluster['Latitude'], cluster['Longitude']]],
        weight=row['Predicted_Allocation']/10,
        color='blue'
    ).add_to(m)

m.save("allocation_map.html")
