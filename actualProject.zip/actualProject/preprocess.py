import pandas as pd
import numpy as np
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter

# ===============================
# FCI Warehouse Data Preprocessing
# ===============================

# Load FCI warehouses (make sure your CSV exists)
fci_df = pd.read_csv("fci_warehouses.csv")  # Columns: State, Owned_LMT, Hired_LMT

# Hardcode lat/lon for states
state_coords = {
    "Bihar": (25.0961, 85.3131),
    "Jharkhand": (23.6102, 85.2799),
    "Odisha": (20.9517, 85.0985),
    "West Bengal": (22.9868, 87.8550),
    "Sikkim": (27.5330, 88.5122),
    "Assam": (26.2006, 92.9376),
    "Arunachal Pradesh": (28.2180, 94.7278),
    "Meghalaya": (25.4670, 91.3662),
    "Mizoram": (23.1645, 92.9376),
    "Tripura": (23.9408, 91.9882),
    "Manipur": (24.6637, 93.9063),
    "Nagaland": (26.1584, 94.5624),
    "Delhi": (28.6139, 77.2090),
    "Haryana": (29.0588, 76.0856),
    "Himachal Pradesh": (31.1048, 77.1734),
    "Jammu & Kashmir": (33.7782, 76.5762),
    "Ladakh": (34.1526, 77.5771),
    "Punjab": (31.1471, 75.3412),
    "Chandigarh": (30.7333, 76.7794),
    "Rajasthan": (27.0238, 74.2179),
    "Uttar Pradesh": (26.8467, 80.9462),
    "Uttarakhand": (30.0668, 79.0193),
    "Andhra Pradesh": (15.9129, 79.7400),
    "A&N Island": (11.7401, 92.6586),
    "Telangana": (18.1124, 79.0193),
    "Kerala": (10.8505, 76.2711),
    "Karnataka": (15.3173, 75.7139),
    "Lakshadweep": (10.3280, 72.7846),
    "Tamil Nadu": (11.1271, 78.6569),
    "Puducherry": (11.9416, 79.8083),
    "Gujarat": (22.2587, 71.1924),
    "D&NH and D&D": (20.1809, 73.0169),
    "Maharashtra": (19.7515, 75.7139),
    "Goa": (15.4909, 73.8278),
    "Madhya Pradesh": (23.4733, 77.9470),
    "Chhattisgarh": (21.2787, 81.8661)
}

fci_df['Latitude'] = fci_df['State'].map(lambda x: state_coords.get(x, (np.nan, np.nan))[0])
fci_df['Longitude'] = fci_df['State'].map(lambda x: state_coords.get(x, (np.nan, np.nan))[1])

# Compute total warehouse capacity (in LMT)
fci_df['Total_Capacity_LMT'] = fci_df['Owned_LMT'] + fci_df['Hired_LMT']

fci_df.to_csv("fci_warehouses_geo.csv", index=False)
print("FCI warehouse data preprocessed and saved!")

# ===============================
# Disaster Data Preprocessing
# ===============================

# Load disaster dataset
dis_df = pd.read_csv(
    "public_emdat_custom_request_2025-10-24_f8675899-bef2-4f24-bdab-a8e1a90dda95.csv",
    low_memory=False
)

# Filter disasters only for 2025
dis_df = dis_df[dis_df['Start Year'] == 2025]

# Fill missing Total Affected as 0
dis_df['Total_Affected'] = dis_df['Total Affected'].fillna(0)

# Convert demand to LMT (assuming 100kg per person -> 0.001 LMT)
RELIEF_TONNES_PER_PERSON = 0.1  # 100 kg/person
dis_df['Demand_LMT'] = dis_df['Total_Affected'] * RELIEF_TONNES_PER_PERSON / 100

# Initialize geocoder for disasters
geolocator_dis = Nominatim(user_agent="disaster_geocoder")
geocode_dis = RateLimiter(geolocator_dis.geocode, min_delay_seconds=1, max_retries=3)

# Function to fill missing lat/lon using geocoding
# Function to fill missing lat/lon using geocoding
def get_dis_coords(row):
    if pd.notnull(row.get('Latitude')) and pd.notnull(row.get('Longitude')):
        return pd.Series([row['Latitude'], row['Longitude']])
    try:
        location = geocode_dis(f"{row['Location']}, {row['Country']}")
        if location:
            return pd.Series([location.latitude, location.longitude])
    except:
        pass
    return pd.Series([np.nan, np.nan])

# Apply geocoding only to missing coordinates
dis_df[['Latitude', 'Longitude']] = dis_df.apply(get_dis_coords, axis=1)


# Apply geocoding only to missing coordinates
dis_df[['Latitude', 'Longitude']] = dis_df.apply(get_dis_coords, axis=1)

# Drop any rows still missing coordinates
dis_df = dis_df.dropna(subset=['Latitude', 'Longitude'])

# Save preprocessed disasters
dis_df.to_csv("disasters_2025_geo.csv", index=False)
print("Disaster data for 2025 preprocessed and saved!")
