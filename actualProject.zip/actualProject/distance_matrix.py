import pandas as pd
import numpy as np
from math import radians, cos, sin, asin, sqrt

# Load processed data
fci_df = pd.read_csv("fci_warehouses_geo.csv")
cluster_df = pd.read_csv("disaster_cluster_summary.csv")

# Haversine distance function
def haversine(lat1, lon1, lat2, lon2):
    R = 6371  # km
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    c = 2 * asin(sqrt(a))
    return R * c

# Compute distance matrix
distances = []
for _, w in fci_df.iterrows():
    for _, c in cluster_df.iterrows():
        dist = haversine(w['Latitude'], w['Longitude'], c['Centroid_Latitude'], c['Centroid_Longitude'])
        distances.append({
            'Warehouse': w['State'],
            'Cluster_ID': c['Cluster_ID'],
            'Distance_km': dist,
            'Warehouse_Capacity_LMT': w['Total_Capacity_LMT'],
            'Cluster_Demand_LMT': c['Total_Demand_LMT']
        })

dist_df = pd.DataFrame(distances)
dist_df.to_csv("warehouse_disaster_distances.csv", index=False)
print("Warehouse-disaster distance matrix saved!")
